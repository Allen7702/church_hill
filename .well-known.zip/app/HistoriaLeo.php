<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistoriaLeo extends Model
{
    //
    protected $fillable = ['kichwa','tarehe','uchapishaji','maelezo','picha','imewekwa_na'];
}
