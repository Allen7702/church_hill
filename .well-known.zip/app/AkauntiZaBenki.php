<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AkauntiZaBenki extends Model
{
    //
    protected $fillable = ['jina_la_benki','jina_la_akaunti','akaunti_namba','tawi','hali_ya_akaunti','maelezo'];
}
