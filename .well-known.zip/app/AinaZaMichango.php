<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AinaZaMichango extends Model
{
    //
    protected $fillable = ['aina_ya_mchango','slug','maelezo'];
}
