<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatumiziBenki extends Model
{
    //
    protected $fillable = ['namba_ya_ankra','kiasi','imewekwa_na','tarehe','aina_ya_ulipaji','namba_nukushi','akaunti_namba','aina_ya_matumizi','maelezo','kundi'];
}
