<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WatoaHuduma extends Model
{
    //
    protected $fillable = ['jina_kamili','anwani','aina_ya_huduma','mawasiliano','maelezo'];
}
