<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kanda extends Model
{
    //
    protected $fillable = ['jina_la_kanda','idadi_ya_jumuiya','slug','herufi_ufupisho','comment','uniqueness'];
}
