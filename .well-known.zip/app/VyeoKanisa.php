<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VyeoKanisa extends Model
{
    //
    protected $fillable = ['jina_la_cheo','maelezo','slug'];
}
