<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MessageShukraniUkumbusho extends Model
{
    //
    protected $fillable = ['kichwa','kundi','ujumbe','aina_ya_toleo'];
}
