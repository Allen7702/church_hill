<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MatumiziTaslimu extends Model
{
    //
    protected $fillable = ['namba_ya_ankra','kiasi','imewekwa_na','tarehe','aina_ya_ulipaji','aina_ya_matumizi','maelezo','kundi'];
}
