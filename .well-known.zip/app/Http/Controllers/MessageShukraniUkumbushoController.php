<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\MessageShukraniUkumbusho;
use App\Message;
use App\Zaka;
use App\AinaZaMichango;
use App\MichangoTaslimu;
use App\MichangoBenki;
use App\MessageBalance;
use App\Mwanafamilia;
use Validator;
use Carbon;
use DB;

class MessageShukraniUkumbushoController extends Controller
{
    //
    public function shukrani_ukumbusho_index(){

        //message statistics
        $today_message = Message::whereDate('created_at',Carbon::now()->format('Y-m-d'))->sum('idadi');

        //total messages
        $total_messages = Message::sum('idadi');

        //this year
        $this_year = Message::whereYear('created_at',Carbon::now()->format('Y'))->sum('idadi');

        //last year
        $last_year = Message::whereYear('created_at',Carbon::now()->subYear(1)->format('Y'))->sum('idadi');

        //this month
        $this_month = Message::whereMonth('created_at',Carbon::now()->format('m'))->whereYear('created_at',Carbon::now()->format('Y'))->sum('idadi');

        //this week
        $this_week = Message::whereBetween('created_at', [Carbon::now()->startOfWeek(), Carbon::now()->endOfWeek()])->sum('idadi');

        //sms balance
        $sms_balance = $this->getSmsBalance();

        $data_sample = MessageShukraniUkumbusho::latest()->get();
        return view('backend.message.shukrani_ukumbusho',compact(['data_sample','today_message','total_messages','this_year','last_year','this_month','this_week','sms_balance']));
    }

    public function shukrani_ukumbusho_sample(){
        $data_ujumbe = MessageShukraniUkumbusho::latest()->get();
        $data_aina = AinaZaMichango::latest()->get();
        return view('backend.message.shukrani_ukumbusho_sample',compact(['data_ujumbe','data_aina']));
    }

    //saving the message template
    public function shukrani_ukumbusho_save(Request $request){
        //getting data
        $must = [
            'kichwa' => 'required|unique:message_shukrani_ukumbushos',
            'kundi' => 'required',
            'aina_ya_toleo' => 'required',
            'ujumbe' => 'required',
        ];

        $error = Validator::make($request->all(),$must);

        if($error->fails()){
            return response()->json(['errors'=>"Hakikisha umejaza sehemu zote zinazohitajika.. kichwa kisijirudie.."]);
        }

        //checking if we are having the shukrani then we must have $jina and $kiasi specified
        $kundi = $request->kundi;

        $ujumbe = $request->ujumbe;

        if($kundi == "shukrani"){
            //validating the kiasi and jina
            $jina = "\$jina";
            $kiasi = "\$kiasi";
            $mwezi = "\$mwezi";

            //verifying the jina
            if(!(strpos($ujumbe,$jina)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$jina kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha jina la muumini.."]);
            }

            //verifying the kiasi
            if(!(strpos($ujumbe,$kiasi)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$kiasi kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha kiasi kilichotolewa na muumini.."]);
            }

            //verifying the mwezi
            if(!(strpos($ujumbe,$mwezi)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$mwezi kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha mwezi husika.."]);
            }
        }

        else{
            //since it is a reminder we only need a name only kiasi is optional
            //verifying the jina
            $jina = "\$jina";
            $mwezi = "\$mwezi";

            if(!(strpos($ujumbe,$jina)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$jina kwenye ujumbe wako kwakua ujumbe wa ukumbusho utahusisha jina la muumini.."]);
            }

            //verifying the mwezi
            if(!(strpos($ujumbe,$mwezi)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$mwezi kwenye ujumbe wako kwakua ujumbe wa ukumbusho utahusisha mwezi husika.."]);
            }
        }

        //saving data
        $data_save = [
            'kichwa' => $request->kichwa,
            'kundi' => $kundi,
            'ujumbe' => $ujumbe,
            'aina_ya_toleo' => $request->aina_ya_toleo,
        ];

        $success = MessageShukraniUkumbusho::create($data_save);

        if($success){
            return response()->json(['success'=>"Ujumbe umehifadhiwa kikamilifu.."]);
        }
        else{
            return response()->json(['errors'=>"Imeshindikana kuhifadhi ujumbe jaribu tena.."]);
        }
    }

    //function to populate data in the modal
    public function shukrani_ukumbusho_edit($id){
        $data = MessageShukraniUkumbusho::findOrFail($id);
        return response()->json(['result'=>$data]);
    }

    //updating the message template
    public function shukrani_ukumbusho_update(Request $request){

        //existing data
        $existing = MessageShukraniUkumbusho::findOrFail($request->hidden_id);

        $must = [
            'kichwa' => 'required|unique:message_shukrani_ukumbushos,kichwa,'.$existing->id,
            'kundi' => 'required',
            'aina_ya_toleo' => 'required',
            'ujumbe' => 'required',
        ];

        $error = Validator::make($request->all(),$must);

        if($error->fails()){
            return response()->json(['errors'=>"Hakikisha umejaza sehemu zote zinazohitajika.. kichwa kisijirudie.."]);
        }

        //checking if we are having the shukrani then we must have $jina and $kiasi specified
        $kundi = $request->kundi;

        $ujumbe = $request->ujumbe;

        if($kundi == "shukrani"){

            //validating the kiasi and jina
            $jina = "\$jina";
            $kiasi = "\$kiasi";
            $mwezi = "\$mwezi";

            //verifying the jina
            if(!(strpos($ujumbe,$jina)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$jina kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha jina la muumini.."]);
            }

            //verifying the kiasi
            if(!(strpos($ujumbe,$kiasi)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$kiasi kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha kiasi kilichotolewa na muumini.."]);
            }

            //verifying the mwezi
            if(!(strpos($ujumbe,$mwezi)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$mwezi kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha mwezi husika.."]);
            }
        }

        else{
            //since it is a reminder we only need a name only kiasi is optional
            //verifying the jina
            $jina = "\$jina";
            $mwezi = "\$mwezi";

            if(!(strpos($ujumbe,$jina)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$jina kwenye ujumbe wako kwakua ujumbe wa ukumbusho utahusisha jina la muumini.."]);
            }

            //verifying the mwezi
            if(!(strpos($ujumbe,$mwezi)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$mwezi kwenye ujumbe wako kwakua ujumbe wa ukumbusho utahusisha mwezi husika.."]);
            }
        }

        //updating data
        $data_update = [
            'kichwa' => $request->kichwa,
            'kundi' => $kundi,
            'ujumbe' => $ujumbe,
            'aina_ya_toleo' => $request->aina_ya_toleo,
        ];

        $success = MessageShukraniUkumbusho::whereId($request->hidden_id)->update($data_update);

        if($success){
            return response()->json(['success'=>"Ujumbe umebadilishwa kikamilifu.."]);
        }
        else{
            return response()->json(['errors'=>"Imeshindikana kubadili ujumbe jaribu tena.."]);
        }
    }

    public function shukrani_ukumbusho_destroy($id){
        $data = MessageShukraniUkumbusho::findOrFail($id);

        if($data->delete()){
            return response()->json(['success'=>"Ujumbe umefutwa kikamilifu.."]);
        }
        else{
            return response()->json(['errors'=>"imeshindikana kufuta ujumbe.."]);
        }
    }

    //function to get the message template
    public function shukrani_ukumbusho_message(Request $request){
        $kichwa_id = $request->kichwa_id;

        //getting the message
        $data = MessageShukraniUkumbusho::findOrFail($kichwa_id);

        if($data == ""){
            return response()->json(['errors'=>"Hakuna taarifa za ujumbe kwa kichwa husika.."]);
        }
        else{
            return response()->json(['result'=>$data]);
        }
    }

    //function to handle the messages
    public function shukrani_ukumbusho_send(Request $request){
        //getting the date
        $mwezi = $request->mwezi;
        $kichwa = $request->kichwa;
        $ujumbe = $request->ujumbe;
        $aina_ya_toleo = $request->aina_ya_toleo;
        $kundi = $request->kundi;
        $mwezi_query = $mwezi; //to be used in getting the details for michango and zakas
        $number_of_message = $request->number_of_message;

        //checking for empty values
        if($mwezi == ""){
            return response()->json(['errors'=>"Hakikisha umejaza mwezi.."]);
        }

        //what if we have empty kichwa
        if($kichwa == ""){
            return response()->json(['errors'=>"Hakikisha umejaza aina ya ujumbe.."]);
        }

        //verifying ujumbe wenyewe
        if($ujumbe == ""){
            return response()->json(['errors'=>"Hakikisha umejaza ujumbe wa kutumwa.."]);
        }

        //validating if we have the kiasi, mwezi and jina in message
        if($kundi == "shukrani"){

            //validating the kiasi and jina
            $jina_verify = "\$jina";
            $kiasi_verify = "\$kiasi";
            $mwezi_verify = "\$mwezi";

            //verifying the jina
            if(!(strpos($ujumbe,$jina_verify)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$jina kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha jina la muumini.."]);
            }

            //verifying the kiasi
            if(!(strpos($ujumbe,$kiasi_verify)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$kiasi kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha kiasi kilichotolewa na muumini.."]);
            }

            //verifying the mwezi
            if(!(strpos($ujumbe,$mwezi_verify)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$mwezi kwenye ujumbe wako kwakua ujumbe wa shukrani utahusisha mwezi husika.."]);
            }

        }

        else{

            //since it is a reminder we only need a name only kiasi is optional
            //verifying the jina
            $jina_verify = "\$jina";
            $mwezi_verify = "\$mwezi";

            if(!(strpos($ujumbe,$jina_verify)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$jina kwenye ujumbe wako kwakua ujumbe wa ukumbusho utahusisha jina la muumini.."]);
            }

            //verifying the mwezi
            if(!(strpos($ujumbe,$mwezi_verify)!==false)){
                return response()->json(['errors'=>"Hakikisha umehusisha alama ya \$mwezi kwenye ujumbe wako kwakua ujumbe wa ukumbusho utahusisha mwezi husika.."]);
            }

        }

        //converting the mwezi to another format
        $mwezi_u = $mwezi;
        $mwezi = Carbon::parse($mwezi)->format('d-F-Y');
        $mwezi_ukumbusho = Carbon::parse($mwezi_u)->format('F-Y');

        //getting list of people based on aina
        if($aina_ya_toleo == "zaka"){
            //getting a list of people who contribute za within specific month

            if($kundi == "shukrani"){

                //getting list of all the people who contributed to zaka
                // $data_michango = DB::table('zakas')->select(DB::raw("SUM(zakas.kiasi) as kiasi"), DB::raw("MONTH(zakas.tarehe) as mwezi"),'zakas.mwanajumuiya','mwanafamilias.mawasiliano','mwanafamilias.jina_kamili')
                //     ->leftJoin('mwanafamilias','mwanafamilias.id','=','zakas.mwanajumuiya')
                //     ->whereMonth('zakas.tarehe',Carbon::parse($mwezi_query)->format('m'))
                //     ->whereYear('zakas.tarehe',Carbon::parse($mwezi_query)->format('Y'))
                //     ->groupBy('zakas.mwanajumuiya')
                //     ->get();

                $data_michango = DB::table('zakas')->select(DB::raw("SUM(zakas.kiasi) as kiasi"), DB::raw("MONTH(zakas.tarehe) as mwezi"),'zakas.mwanajumuiya','mwanafamilias.mawasiliano','mwanafamilias.jina_kamili')
                    ->whereNotNull('mwanafamilias.mawasiliano')
                    ->leftJoin('mwanafamilias','mwanafamilias.id','=','zakas.mwanajumuiya')
                    ->whereDate('zakas.tarehe',Carbon::parse($mwezi_query)->format('Y-m-d'))
                    ->groupBy('zakas.mwanajumuiya')
                    ->get();

                //means we have some people who contributed to zaka
                if($data_michango->isNotEmpty()){

                    //function to clean the message and append amount and name //TODO fix here check the response says no waliotoa zaka why?
                    $cleaned_message_numbers = $this->cleanShukraniMessage($data_michango,$mwezi,$ujumbe);

                    if($cleaned_message_numbers == "CODE2021"){
                        return response()->json(['errors'=>"Hakuna taarifa za waliotoa zaka tarehe $mwezi .."]);
                    }
                    else{
                        $message = count($cleaned_message_numbers);

                        //before sending getting the balance first
                        $total_sms = $message * $number_of_message;
                        $sms_balance = $this->getSmsBalance();

                        if($total_sms > $sms_balance){
                            return response()->json(['errors'=>"Salio la meseji halitoshi kutuma meseji $total_sms tafadhali ongeza salio.."]);
                        }

                        $statue = $this->sendingMessage($cleaned_message_numbers);

                        if($statue == "SUCCESS"){
                            $data_save = [
                                'mtumaji' => auth()->user()->email,
                                'mpokeaji' => "waliotoa zaka",
                                'ujumbe' => $ujumbe,
                                'status' => "CODE",
                                'idadi' => $total_sms,
                                'tarehe' => date('Y-m-d'),
                            ];

                            Message::create($data_save);

                            //deducting the balance
                            MessageBalance::decrement('balance',$total_sms);

                            return response()->json(['success'=>"Meseji zote zimetumwa kikamilifu.."]);
                        }

                        elseif($statue == "FAILED_ALL"){
                            return response()->json(['errors'=>"Imeshindikana kutuma meseji za shukrani jaribu tena baadae.."]);
                        }
                        else{
                            $gap = $total_sms - $statue;

                            $data_save = [
                                'mtumaji' => auth()->user()->email,
                                'mpokeaji' => "waliotoa mchango $mchango",
                                'ujumbe' => $ujumbe,
                                'status' => "CODE",
                                'idadi' => $gap,
                                'tarehe' => date('Y-m-d'),
                            ];

                            Message::create($data_save);
                            //deducting the balance
                            MessageBalance::decrement('balance',$gap);

                            return response()->json(['info'=>"Jumla ya meseji $gap zimetumwa kati ya $total_sms"]);
                        }
                    }
                }

                //means we don't have anyone who contributed
                else{
                    //return the message that we don't have any one who contributed hence consider to remind them
                    return response()->json(['errors'=>"Hakuna waamini waliotoa Zaka kwa tarehe $mwezi.."]);
                }
            }

            else{
                //consider to remind them
                //getting list of all the people who contributed to zaka

                $data_michango = DB::table('zakas')->select(DB::raw("SUM(zakas.kiasi) as kiasi"), DB::raw("MONTH(zakas.tarehe) as mwezi"),'zakas.mwanajumuiya','mwanafamilias.mawasiliano','mwanafamilias.jina_kamili')
                    ->whereNotNull('mwanafamilias.mawasiliano')
                    ->leftJoin('mwanafamilias','mwanafamilias.id','=','zakas.mwanajumuiya')
                    ->whereMonth('zakas.tarehe',Carbon::parse($mwezi_query)->format('m'))
                    ->whereYear('zakas.tarehe',Carbon::parse($mwezi_query)->format('Y'))
                    ->groupBy('zakas.mwanajumuiya')
                    ->get();

                //filtering all the data and remain with ids only
                $data_ids = [];

                if($data_michango->isNotEmpty()){
                    foreach($data_michango as $data){
                        array_push($data_ids,$data->mwanajumuiya);
                    }

                    //spotting out those who did not pay
                    $data_wasiolipa = Mwanafamilia::whereNotIn('id',$data_ids)->where('ubatizo','tayari')->whereNotNull('mawasiliano')->select('jina_kamili','mawasiliano')->get();

                    if($data_wasiolipa->isEmpty()){
                        return response()->json(['info'=>"Hakuna orodha ya waamini wasiolipa zaka kwa mwezi $mwezi_ukumbusho"]);
                    }

                    else{
                        //function to clean the message and append amount and name

                        //------------------ IMPORTANT CONCEPT ---------------- */
                        $mwezi = $mwezi_ukumbusho; //here we assign the month since the message of ukumbusho does not state date
                        $cleaned_message_numbers = $this->cleanUkumbushoMessage($data_wasiolipa,$mwezi,$ujumbe);

                        if($cleaned_message_numbers == "CODE2021"){
                            return response()->json(['errors'=>"Hakuna taarifa za wasiotoa zaka kwa mwezi $mwezi_ukumbusho .."]);
                        }
                        else{
                            //counting total message
                            $message = count($cleaned_message_numbers);

                            //before sending getting the balance first
                            $total_sms = $number_of_message * $message;
                            $sms_balance = $this->getSmsBalance();

                            if($total_sms > $sms_balance){
                                return response()->json(['errors'=>"Salio la meseji halitoshi kutuma meseji $total_sms tafadhali ongeza salio.."]);
                            }

                            $statue = $this->sendingMessage($cleaned_message_numbers);

                            if($statue == "SUCCESS"){
                                //saving message
                                $data_save = [
                                    'mtumaji' => auth()->user()->email,
                                    'mpokeaji' => "wasiotoa zaka",
                                    'ujumbe' => $ujumbe,
                                    'status' => "CODE",
                                    'idadi' => $total_sms,
                                    'tarehe' => date('Y-m-d'),
                                ];

                                Message::create($data_save);

                                //deducting the balance
                                MessageBalance::decrement('balance',$total_sms);

                                return response()->json(['success'=>"Meseji zote zimetumwa kikamilifu.."]);

                            }

                            elseif($statue == "FAILED_ALL"){
                                return response()->json(['errors'=>"Imeshindikana kutuma meseji za shukrani jaribu tena baadae.."]);
                            }
                            else{
                                $gap = $total_sms - $statue;
                                //deducting the balance
                                MessageBalance::decrement('balance',$gap);
                                return response()->json(['info'=>"Jumla ya meseji $gap zimetumwa kati ya $total_sms"]);
                            }
                        }
                    }
                }

                //means empty no one contributed
                else{

                    //means no one contributed hence remind all the people in mwanafamilia who got ubatizo
                    $data_wasiolipa = Mwanafamilia::latest()->whereNotNull('mawasiliano')->where('ubatizo','tayari')->select('jina_kamili','mawasiliano')->get();

                    //function to clean the message and append amount and name

                    //------------------ IMPORTANT CONCEPT ---------------- */
                    $mwezi = $mwezi_ukumbusho; //FIX here we assign the month since the message of ukumbusho does not state date
                    $cleaned_message_numbers = $this->cleanUkumbushoMessage($data_wasiolipa,$mwezi,$ujumbe);

                    // return $cleaned_message_numbers;
                    if($cleaned_message_numbers == "CODE2021"){
                        return response()->json(['errors'=>"Hakuna taarifa za wasiotoa zaka kwa mwezi $mwezi_ukumbusho husika.."]);
                    }

                    else{
                        //counting total message
                        $message = count($cleaned_message_numbers);

                        //before sending getting the balance first
                        $total_sms = $number_of_message * $message;
                        $sms_balance = $this->getSmsBalance();

                        if($total_sms > $sms_balance){
                            return response()->json(['errors'=>"Salio la meseji halitoshi kutuma meseji $total_sms tafadhali ongeza salio.."]);
                        }

                        $statue = $this->sendingMessage($cleaned_message_numbers);

                        if($statue == "SUCCESS"){
                            //saving message
                            $data_save = [
                                'mtumaji' => auth()->user()->email,
                                'mpokeaji' => "wasiotoa zaka",
                                'ujumbe' => $ujumbe,
                                'status' => "CODE",
                                'idadi' => $total_sms,
                                'tarehe' => date('Y-m-d'),
                            ];

                            Message::create($data_save);

                            //deducting the balance
                            MessageBalance::decrement('balance',$total_sms);

                            return response()->json(['success'=>"Meseji zote zimetumwa kikamilifu.."]);

                        }

                        elseif($statue == "FAILED_ALL"){
                            return response()->json(['errors'=>"Imeshindikana kutuma meseji za shukrani jaribu tena baadae.."]);
                        }

                        else{
                            $gap = $message - $statue;

                            $data_save = [
                                'mtumaji' => auth()->user()->email,
                                'mpokeaji' => "wasiotoa zaka",
                                'ujumbe' => $ujumbe,
                                'status' => "CODE",
                                'idadi' => $gap,
                                'tarehe' => date('Y-m-d'),
                            ];

                            Message::create($data_save);
                            //deducting the balance
                            MessageBalance::decrement('balance',$gap);
                            return response()->json(['info'=>"Jumla ya meseji $gap zimetumwa kati ya $total_sms"]);
                        }
                    }
                }
            }

        }
        else{

            //means other kinds of michango
            if($kundi == "shukrani"){

                //getting data from mchango specific to those who contribute
                $data = MessageShukraniUkumbusho::findOrFail($kichwa);

                if($data == ""){
                    return response()->json(['Taarifa za mchango husika hazipo..']);
                }
                else{
                    $mchango = $data->aina_ya_toleo;
                }

                //================================= COMBINE THE MICHANGO OF BENKI AND TASLIMU TO FORM SINGLE TABLE=======================================================================================================================================================
                // $michango_taslimu = DB::table('michango_taslimus')->select(DB::raw("SUM(kiasi) as kiasi"), DB::raw("MONTH(tarehe) as mwezi"),'mwanafamilia','aina_ya_mchango')
                //     ->where('aina_ya_mchango',$aina_ya_toleo)
                //     ->whereMonth('tarehe',Carbon::parse($mwezi_query)->format('m'))
                //     ->whereYear('tarehe',Carbon::parse($mwezi_query)->format('Y'))
                //     ->groupBy('mwanafamilia');
                $michango_taslimu = DB::table('michango_taslimus')->select(DB::raw("SUM(kiasi) as kiasi"), DB::raw("MONTH(tarehe) as mwezi"),'mwanafamilia','aina_ya_mchango')
                    ->where('aina_ya_mchango',$aina_ya_toleo)
                    ->whereDate('tarehe',Carbon::parse($mwezi_query)->format('Y-m-d'))
                    ->groupBy('mwanafamilia');

                $michango_benki = DB::table('michango_benkis')->select(DB::raw("SUM(kiasi) as kiasi"), DB::raw("MONTH(tarehe) as mwezi"),'mwanafamilia','aina_ya_mchango')
                    ->where('aina_ya_mchango',$aina_ya_toleo)
                    ->whereDate('tarehe',Carbon::parse($mwezi_query)->format('Y-m-d'))
                    ->groupBy('mwanafamilia');

                $combined = $michango_taslimu->unionAll($michango_benki);

                $data_michango = DB::table(DB::raw("({$combined->toSql()}) AS merged"))
                    ->mergeBindings($combined)
                    ->select(DB::raw("SUM(kiasi) as kiasi"),'merged.mwanafamilia','merged.aina_ya_mchango','mwanafamilias.mawasiliano','mwanafamilias.jina_kamili')
                    ->whereNotNull('mwanafamilias.mawasiliano')
                    ->leftJoin('mwanafamilias','mwanafamilias.id','=','merged.mwanafamilia')
                    ->groupBy('merged.mwanafamilia')
                    ->get();

                //function to clean the message and append amount and name
                $cleaned_message_numbers = $this->cleanShukraniMessage($data_michango,$mwezi,$ujumbe);

                if($cleaned_message_numbers == "CODE2021"){
                    return response()->json(['errors'=>"Hakuna taarifa za waliotoa michango kwa tarehe $mwezi_ukumbusho .."]);
                }
                else{

                    $message = count($cleaned_message_numbers);

                    //before sending getting the balance first
                    $total_sms = $number_of_message * $message;
                    $sms_balance = $this->getSmsBalance();

                    if($total_sms > $sms_balance){
                        return response()->json(['errors'=>"Salio la meseji halitoshi kutuma meseji $total_sms tafadhali ongeza salio.."]);
                    }

                    $statue = $this->sendingMessage($cleaned_message_numbers);

                    if($statue == "SUCCESS"){
                        $data_save = [
                            'mtumaji' => auth()->user()->email,
                            'mpokeaji' => "waliotoa mchango $mchango",
                            'ujumbe' => $ujumbe,
                            'status' => "CODE",
                            'idadi' => $total_sms,
                            'tarehe' => date('Y-m-d'),
                        ];

                        Message::create($data_save);

                        //deducting the balance
                        MessageBalance::decrement('balance',$total_sms);

                        return response()->json(['success'=>"Meseji zote zimetumwa kikamilifu.."]);
                    }

                    elseif($statue == "FAILED_ALL"){
                        return response()->json(['errors'=>"Imeshindikana kutuma meseji za shukrani jaribu tena baadae.."]);
                    }
                    else{

                        $gap = $total_sms - $statue;

                        $data_save = [
                            'mtumaji' => auth()->user()->email,
                            'mpokeaji' => "waliotoa mchango $mchango",
                            'ujumbe' => $ujumbe,
                            'status' => "CODE",
                            'idadi' => $gap,
                            'tarehe' => date('Y-m-d'),
                        ];

                        Message::create($data_save);
                        //deducting the balance
                        MessageBalance::decrement('balance',$gap);

                        return response()->json(['info'=>"Jumla ya meseji $gap zimetumwa kati ya $total_sms"]);
                    }
                }
            }

            //================================== THOSE WHO DID NOT PAY =======================
            else{

                //getting data from mchango specific to those who contribute
                $data = MessageShukraniUkumbusho::findOrFail($kichwa);

                if($data == ""){
                    return response()->json(['Taarifa za mchango husika hazipo..']);
                }
                else{
                    $mchango = $data->aina_ya_toleo;
                }

                //================================= COMBINE THE MICHANGO OF BENKI AND TASLIMU TO FORM SINGLE TABLE=======================================================================================================================================================
                $michango_taslimu = DB::table('michango_taslimus')->select(DB::raw("SUM(kiasi) as kiasi"), DB::raw("MONTH(tarehe) as mwezi"),'mwanafamilia','aina_ya_mchango')
                    ->where('aina_ya_mchango',$aina_ya_toleo)
                    ->whereMonth('tarehe',Carbon::parse($mwezi_query)->format('m'))
                    ->whereYear('tarehe',Carbon::parse($mwezi_query)->format('Y'))
                    ->groupBy('mwanafamilia');

                $michango_benki = DB::table('michango_benkis')->select(DB::raw("SUM(kiasi) as kiasi"), DB::raw("MONTH(tarehe) as mwezi"),'mwanafamilia','aina_ya_mchango')
                    ->where('aina_ya_mchango',$aina_ya_toleo)
                    ->whereMonth('tarehe',Carbon::parse($mwezi_query)->format('m'))
                    ->whereYear('tarehe',Carbon::parse($mwezi_query)->format('Y'))
                    ->groupBy('mwanafamilia');

                $combined = $michango_taslimu->unionAll($michango_benki);

                $data_michango = DB::table(DB::raw("({$combined->toSql()}) AS merged"))
                    ->mergeBindings($combined)
                    ->select(DB::raw("SUM(kiasi) as kiasi"),'merged.mwanafamilia','merged.aina_ya_mchango','mwanafamilias.mawasiliano','mwanafamilias.jina_kamili')
                    ->whereNotNull('mwanafamilias.mawasiliano')
                    ->leftJoin('mwanafamilias','mwanafamilias.id','=','merged.mwanafamilia')
                    ->groupBy('merged.mwanafamilia')
                    ->get();

                //filtering all the data and remain with ids only
                $data_ids = [];

                if($data_michango->isNotEmpty()){
                    foreach($data_michango as $data){
                        array_push($data_ids,$data->mwanafamilia);
                    }

                    //spotting out those who did not pay
                    $data_wasiolipa = Mwanafamilia::whereNotIn('id',$data_ids)->whereNotNull('mawasiliano')->where('ubatizo','tayari')->select('jina_kamili','mawasiliano')->get();

                    if($data_wasiolipa->isEmpty()){
                        return response()->json(['info'=>"Waamini wote wamelipa mchango wa $mchango"]);
                    }
                    else{
                        //function to clean the message and append amount and name

                        //------------------ IMPORTANT CONCEPT ---------------- */
                        $mwezi = $mwezi_ukumbusho; //fix here we assign the month since the message of ukumbusho does not state date
                        $cleaned_message_numbers = $this->cleanUkumbushoMessage($data_wasiolipa,$mwezi,$ujumbe);

                        if($cleaned_message_numbers == "CODE2021"){
                            return response()->json(['errors'=>"Hakuna taarifa za wasiotoa michango kwa mwezi $mwezi_ukumbusho husika.."]);
                        }
                        else{
                            //counting total message
                            $message = count($cleaned_message_numbers);

                            //before sending getting the balance first
                            $total_sms = $total_sms * $message;
                            $sms_balance = $this->getSmsBalance();

                            if($total_sms > $sms_balance){
                                return response()->json(['errors'=>"Salio la meseji halitoshi kutuma meseji $total_sms tafadhali ongeza salio.."]);
                            }

                            $statue = $this->sendingMessage($cleaned_message_numbers);

                            if($statue == "SUCCESS"){
                                //saving message
                                $data_save = [
                                    'mtumaji' => auth()->user()->email,
                                    'mpokeaji' => "wasiotoa mchango $mchango",
                                    'ujumbe' => $ujumbe,
                                    'status' => "CODE",
                                    'idadi' => $total_sms,
                                    'tarehe' => date('Y-m-d'),
                                ];

                                Message::create($data_save);

                                //deducting the balance
                                MessageBalance::decrement('balance',$total_sms);

                                return response()->json(['success'=>"Meseji zote zimetumwa kikamilifu.."]);

                            }

                            elseif($statue == "FAILED_ALL"){
                                return response()->json(['errors'=>"Imeshindikana kutuma meseji za shukrani jaribu tena baadae.."]);
                            }
                            else{
                                $gap = $total_sms - $statue;
                                //deducting the balance
                                MessageBalance::decrement('balance',$gap);

                                return response()->json(['info'=>"Jumla ya meseji $gap zimetumwa kati ya $total_message"]);
                            }
                        }
                    }
                }

                else{

                    //means no one contributed hence remind all the people in mwanafamilia who got ubatizo
                    $data_wasiolipa = Mwanafamilia::latest()->whereNotNull('mawasiliano')->where('ubatizo','tayari')->select('jina_kamili','mawasiliano')->get();

                    //function to clean the message and append amount and name
                    //------------------ IMPORTANT CONCEPT ---------------- */
                    $mwezi = $mwezi_ukumbusho; //fix here we assign the month since the message of ukumbusho does not state date
                    $cleaned_message_numbers = $this->cleanUkumbushoMessage($data_wasiolipa,$mwezi,$ujumbe);

                    if($cleaned_message_numbers == "CODE2021"){
                        return response()->json(['errors'=>"Hakuna taarifa za wasiotoa michango kwa mwezi $mwezi_ukumbusho .."]);
                    }

                    else{
                        //counting total message
                        $message = count($cleaned_message_numbers);

                        //before sending getting the balance first
                        $total_sms = $number_of_message * $message;
                        $sms_balance = $this->getSmsBalance();

                        if($total_sms > $sms_balance){
                            return response()->json(['errors'=>"Salio la meseji halitoshi kutuma meseji $total_sms tafadhali ongeza salio.."]);
                        }

                        $statue = $this->sendingMessage($cleaned_message_numbers);

                        if($statue == "SUCCESS"){
                            //saving message
                            $data_save = [
                                'mtumaji' => auth()->user()->email,
                                'mpokeaji' => "wasiotoa mchango $mchango",
                                'ujumbe' => $ujumbe,
                                'status' => "CODE",
                                'idadi' => $total_sms,
                                'tarehe' => date('Y-m-d'),
                            ];

                            Message::create($data_save);

                            //deducting the balance
                            MessageBalance::decrement('balance',$total_sms);

                            return response()->json(['success'=>"Meseji zote zimetumwa kikamilifu.."]);

                        }

                        elseif($statue == "FAILED_ALL"){
                            return response()->json(['errors'=>"Imeshindikana kutuma meseji za shukrani jaribu tena baadae.."]);
                        }

                        else{
                            $gap = $total_sms - $statue;

                            $data_save = [
                                'mtumaji' => auth()->user()->email,
                                'mpokeaji' => "wasiotoa mchango $mchango",
                                'ujumbe' => $ujumbe,
                                'status' => "CODE",
                                'idadi' => $gap,
                                'tarehe' => date('Y-m-d'),
                            ];

                            Message::create($data_save);

                            //deducting the balance
                            MessageBalance::decrement('balance',$gap);

                            return response()->json(['info'=>"Jumla ya meseji $gap zimetumwa kati ya $total_sms"]);
                        }
                    }
                }
            }
        }

    }

    //function that clean shukrani messages
    private function cleanShukraniMessage($data_michango,$mwezi,$ujumbe){

        //validating first
        if($data_michango->isNotEmpty()){

            $clean_this = ["\$jina","\$kiasi","\$mwezi"];

            foreach($data_michango as $data){
                $cleaned_text[] = [
                    'namba' => "255".ltrim($data->mawasiliano,0),
                    'ujumbe' => str_replace($clean_this,[$data->jina_kamili,number_format($data->kiasi,2),$mwezi],$ujumbe) //replacing the jina, kiasi and mwezi
                ];
            }

            return $cleaned_text;
        }

        else{
            return "CODE2021";
        }
    }


    //function that clean ukumbusho messages
    private function cleanUkumbushoMessage($data_wasiolipa,$mwezi,$ujumbe){

        //validating first
        if($data_wasiolipa->isNotEmpty()){

            $clean_this = ["\$jina","\$mwezi"];

            foreach($data_wasiolipa as $data){
                $cleaned_text[] = [
                    'namba' => "255".ltrim($data->mawasiliano,0),
                    'ujumbe' => str_replace($clean_this,[$data->jina_kamili,$mwezi],$ujumbe) //replacing the jina and mwezi
                ];
            }

            return $cleaned_text;
        }

        else{
            return "CODE2021";
        }
    }

    // //function to clean all the numbers of waliolipa
    // private function getCleanedNumbers($cleaned_message_numbers){
    //     $id = 0;
    //     foreach($cleaned_message_numbers as $key => $clean){

    //         $new_number = \ltrim($clean['namba'],0);

    //         $cleaned_numbers[] = ['recipient_id' => $id=$id+1,'dest_addr' => "255".$new_number];
    //     }

    //     return $cleaned_numbers;
    // }

    //function to arrange the message of waliolipa
    // private function getCleanedMessages($cleaned_message_numbers){
    //     foreach($cleaned_message_numbers as $key => $clean){
    //         $cleaned_messages[] = $clean['ujumbe'];
    //     }

    //     return $cleaned_messages;
    // }

    //sending single message
    public function sendingMessage($cleaned_message_numbers){
        $api_key = env('BONGO_LIVE_KEY');
        $secret_key = env('BONGO_LIVE_SECRET');
        $sender_info = env('BONGO_SENDER_ID');

        $messages = count($cleaned_message_numbers);
        $errors = 0; //tracking errors
        $success = 0; //tracking success

        foreach($cleaned_message_numbers as $key => $data){
            $namba = $data['namba'];
            $ujumbe = $data['ujumbe'];

            $postData = array(
                'source_addr' => $sender_info,
                'encoding'=>0,
                'schedule_time' => '',
                'message' => $ujumbe,
                'recipients' => [array('recipient_id' => '1','dest_addr'=>$namba)]
            );

            $Url ='https://apisms.beem.africa/v1/send';

            $ch = curl_init($Url);
            error_reporting(E_ALL);
            ini_set('display_errors', 1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt_array($ch, array(
                CURLOPT_POST => TRUE,
                CURLOPT_RETURNTRANSFER => TRUE,
                CURLOPT_HTTPHEADER => array(
                    'Authorization:Basic ' . base64_encode("$api_key:$secret_key"),
                    'Content-Type: application/json'
                ),
                CURLOPT_POSTFIELDS => json_encode($postData)
            ));

            $response = curl_exec($ch);

            if($response === FALSE){
                $failure = $response;
                die(curl_error($ch));
                $errors = $errors + 1;
            }
            else{
                $success =  $success + 1;
            }

        }

        //do something here
        if($errors == 0){
            return "SUCCESS";
        }
        elseif($errors == $messages){
            return "FAILED_ALL";
        }
        else{
            $gap = $messages - $errors;
            // $gap = $message - $errors;
            return $gap;
        }
    }

    //function to handle sms balance
    private function getSmsBalance(){
        $balance = MessageBalance::latest()->value('balance');
        return $balance;
    }

}
