<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use App\CentreDetail;
use Auth;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        Schema::defaultStringLength(191);

    
        view()->composer('*', function ($view) {

            if(Auth::check()){
                //overall details of the church
                $church_details = CentreDetail::first();
                $view->with(['church_details'=>$church_details]);
            }
            elseif(!(Auth::check())){
                $church_details = CentreDetail::value('centre_name');
                $view->with(['church_details'=>$church_details]);
            }
            else{
                $church_details = CentreDetail::select('centre_name');
                return redirect('/home');
            }
        });
    }
}
