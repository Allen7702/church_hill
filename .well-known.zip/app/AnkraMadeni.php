<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AnkraMadeni extends Model
{
    //
    protected $fillable = ['mtoa_huduma','kiasi','namba_ya_ankra','tarehe','status','deni'];
}
