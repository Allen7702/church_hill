<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BajetiMakisioMatumizi extends Model
{
    //
    protected $fillable = ['aina_ya_matumizi','kiasi','kundi','mwaka','maelezo'];
}
