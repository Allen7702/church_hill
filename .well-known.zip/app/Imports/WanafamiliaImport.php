<?php

namespace App\Imports;

use App\Mwanafamilia;
use App\Familia;
use App\Jumuiya;
use App\Kanda;
use App\User;
use Throwable;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\SkipsErrors;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Str;
use Auth;
use Carbon;
use App\MakundiRika;

class WanafamiliaImport implements ToModel,WithHeadingRow,SkipsOnError,WithValidation,SkipsOnFailure,WithBatchInserts,WithChunkReading
{
    use Importable,SkipsErrors,SkipsFailures;
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {

        //setting rika
        $rika = MakundiRika::where('umri_kuanzia','<=',Carbon::parse($this->transformDate($row['dob']))->age)->where('umri_ukomo','>=',Carbon::parse($this->transformDate($row['dob']))->age)->value('rika');

        $data_save = [
            'jina_kamili' => strtoupper($row['jina_kamili']),
            'mawasiliano' => $row['mawasiliano'],
            'jinsia' => ucfirst(strtolower($row['jinsia'])),
            'dob' => $this->transformDate($row['dob']),
            'taaluma' => $row['taaluma'],
            'familia' => $row['familia'],
            'komunio' => $row['komunio'],
            'ekaristi' => $row['ekaristi'],
            'kipaimara' => $row['kipaimara'],
            'ndoa' => strtolower($row['ndoa']),
            // 'cheo' => $row['cheo'],
            'ubatizo' => $row['ubatizo'],
            'aina_ya_ndoa' => $row['aina_ya_ndoa'],
            'namba_ya_cheti' => $row['namba_ya_cheti'],
            'parokia_ya_ubatizo' => $row['parokia_ya_ubatizo'],
            'jimbo_la_ubatizo' => $row['jimbo_la_ubatizo'],
            'cheo_familia' => ucfirst(strtolower($row['cheo_familia'])), 
            'rika' => $rika,
        ];

        $success = Mwanafamilia::create($data_save);

        if($success){
            //incrementing the number of familia
            //tracking
            $jina = strtoupper($row['jina_kamili']);
            $message = "Upakiaji";
            $data = "Upakiaji wa mwanafamilia $jina";
            $this->setActivity($message,$data);

            Familia::whereId($row['familia'])->increment('wanafamilia',1);
        }
    }

    public function rules(): array{
        return [
            '*.familia' => ['exists:App\Familia,id'],
            '*.jina_kamili' => ['required'],
            // '*.mawasiliano' => ['required'],
            // '*.jinsia' => ['required'],
            // '*.dob' => ['required'],
            // '*.taaluma' => ['required'],
            // '*.komunio' => ['required'],
            // '*.ekaristi' => ['required'],
            // '*.kipaimara' => ['required'],
            // '*.ndoa' => ['required'],
            // '*.ubatizo' => ['required'],
            // '*.cheo_familia' => ['required'],
        ];
    }

    //insert 100 record in single
    public function batchSize(): int {
        return 100;
    }

    public function transformDate($value, $format = 'Y-m-d')
    {
        //checking for empty string
        if(!strlen($value)) return null;

        try {
            if($value == ""){

            }
            else{
                return \Carbon\Carbon::instance(\PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($value));
            }
        } 
        catch (\ErrorException $e) {
            return \Carbon\Carbon::createFromFormat($format, $value);
        } 
    }

    //split the excel into 100 rows
    public function chunkSize(): int{
        return 100;
    }

    //method for tracking activity
    private function setActivity($message,$data){
        $model = new Mwanafamilia; 
        activity()
        ->performedOn($model)
        ->causedBy(Auth::user())
        ->withProperties(["Taarifa" => "$data"])
        ->log($message);
    }
}
