<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MajinaUsaidizi extends Model
{
    //
    protected $fillable = ['jina_kamili','mawasiliano','cheo_familia','jumuiya','jinsia','status'];
}
