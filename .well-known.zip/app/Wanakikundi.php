<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wanakikundi extends Model
{
    //
    protected $fillable = ['mwanafamilia','kikundi','maoni','status'];
}
