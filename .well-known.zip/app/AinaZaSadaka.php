<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AinaZaSadaka extends Model
{
    protected $guarded = [];
}
