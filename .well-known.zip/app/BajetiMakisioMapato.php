<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BajetiMakisioMapato extends Model
{
    //
    protected $fillable = ['aina_ya_mapato','kiasi','kundi','mwaka','maelezo'];

}
