<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MakundiRika extends Model
{
    //
    protected $fillable = ['rika','umri_kuanzia','umri_ukomo','maelezo'];
}
