<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Matangazo extends Model
{
    //
    protected $fillable = ['kichwa','tarehe','uchapishaji','maelezo','alama','attachment','imewekwa_na'];
}
