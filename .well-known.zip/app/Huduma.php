<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Huduma extends Model
{
    //
    protected $fillable = ['aina_ya_huduma','maelezo','slug'];
}
