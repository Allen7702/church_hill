<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WanafamiliaUsaidizi extends Model
{
    //
    protected $fillable = ['jina_kamili','jina_la_jumuiya','mawasiliano','cheo_familia','jinsia','maoni','familia_id','slug'];
}
