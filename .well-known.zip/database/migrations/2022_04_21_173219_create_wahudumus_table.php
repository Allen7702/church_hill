<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWahudumusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wahudumus', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ratiba_ya_misa_id')->constrained();
            $table->string('type');
            $table->text('description')->nullable();
            $table->morphs('muhudumuable');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wahudumus');
    }
}
