<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\RatibaYaMisa;
use Faker\Generator as Faker;

$factory->define(RatibaYaMisa::class, function (Faker $faker) {
    return [
        //
    ];
});
