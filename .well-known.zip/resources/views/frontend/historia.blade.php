@extends('layouts.front_master')
@section('content')
<main id="main">

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog" style="margin-top: 10px;">
    <div class="container">

        <div class="section-title" data-aos="fade-up">
            <h2>Historia Leo</h2>
        </div>

        <div class="row">

        <div class="col-lg-8 entries">

            @if($data_historia->isNotEmpty())

            @foreach ($data_historia as $item)
            <article class="entry">

                <div class="entry-img">
                    <img src="{{url('uploads/images/'.$item->picha)}}" alt="" class="img-fluid">
                </div>
    
                <h2 class="entry-title">
                    <a href="{{url('historia_leo')}}">{{$item->kichwa}}</a>
                </h2>
    
                <div class="entry-meta">
                    <ul>
                        <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="{{url('historia_leo')}}"><time datetime="2020-01-01">{{Carbon::parse($item->tarehe)->format('M d, Y')}}</time></a></li>
                    </ul>
                    </div>
    
                    <div class="entry-content">
                    <p>
                        {{$item->maelezo}}
                    </p>
                    
                    </div>
                
                </article>
            @endforeach
            
            @else
            <article class="entry">

                <div class="entry-img">
                <img src="{{url('uploads/church.jpg')}}" alt="" class="img-fluid">
                </div>

                <h2 class="entry-title">
                <a href="{{url('historia_leo')}}">Ukurasa wa historia</a>
                </h2>

                <div class="entry-meta">
                <ul>
                    <li class="d-flex align-items-center"><i class="icofont-wall-clock"></i> <a href="{{url('historia_leo')}}"><time datetime="2020-01-01">{{Carbon::now()->format('M d, Y')}}</time></a></li>
                </ul>
                </div>

                <div class="entry-content">
                <p>
                    Karibu katika ukurasa wa historia za watakatifu mbalimbali, ukurasa huu utahusisha historia za watakatifu mbalimbali walioshiriki kikamilifu katika historia ya kanisa..
                </p>
            
                </div>

            </article>
            @endif
        </div>

        <div class="col-lg-4">

            <div class="sidebar">

            
            <h3 class="sidebar-title">Nyinginezo</h3>
            <div class="sidebar-item recent-posts">

                @if($data_historia->isNotEmpty())
                    
                    @foreach ($data_historia as $row)
                        <div class="post-item clearfix">
                            <img src="{{url('uploads/images/'.$row->picha)}}" alt="picha">
                            <h4><a href="{{url('historia_leo')}}">{{$row->kichwa}}</a></h4>
                            <time datetime="2020-01-01">{{Carbon::parse($row->tarehe)->format('M d, Y')}}</time>
                        </div>
                    @endforeach
                    
                @else
                    <div class="post-item clearfix">
                        <img src="{{url('uploads/church.jpg')}}" alt="picha">
                        <h4><a href="{{url('historia_leo')}}">Historia</a></h4>
                        <time datetime="2020-01-01">{{Carbon::now()->format('M d, Y')}}</time>
                    </div>
                @endif

            </div>

            </div>

        </div>

        </div>

    </div>
    </section>

</main>

@endsection