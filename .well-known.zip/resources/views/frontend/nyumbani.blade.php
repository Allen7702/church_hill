@extends('layouts.front_master')
@section('content')

<section id="hero">
    <div class="hero-container">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

            @if($matukios->isEmpty())

            <div class="carousel-item active" style="background: url({{('/uploads/church.jpg')}});">
                <div class="carousel-container">
                    <div class="carousel-content">
                        <h2 class="animate__animated animate__fadeInDown">Tovuti ya kanisa</h2>
                        <p class="animate__animated animate__fadeInUp">Karibu katika tovuti ya kanisa, kwa taarifa, historia na matangazo mbalimbali tumsifu Yesu Kristo!</p>
                    </div>
                </div>
            </div>
                
            @else
                
                @foreach ($matukios as $item)
                    <div class="carousel-item {{ $loop->first ? 'active' : '' }}" style="background-image: url({{('/uploads/images/'.$item->picha)}});">
                        <div class="carousel-container">
                        <div class="carousel-content">
                            <h2 class="animate__animated animate__fadeInDown">{{$item->kichwa}}</h2>
                            <p class="animate__animated animate__fadeInUp">{{$item->maelezo}}</p>
                        </div>
                        </div>
                    </div>
                @endforeach
            
            @endif
        
        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon icofont-rounded-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon icofont-rounded-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
        </a>

    </div>
    </div>
</section><!-- End Hero -->

<main id="main">

    <section id="featured" class="featured">
        <div class="container">

            <div class="section-title" data-aos="fade-up">
                <h2>Kanda na Jumuiya Zetu</h2>
            </div>

            <div class="row">
            <div class="col-lg-4">
                <div class="icon-box">
                <i class="icofont-listing-number"></i>
                <h3><a href="{{url('kanda_zetu')}}">Kanda zetu</a></h3>
                    @if($kanda_zetu->isNotEmpty())
                        @foreach ($kanda_zetu as $kanda)
                        <p>{{$kanda->jina_la_kanda}}</p>
                        @endforeach
                    @else
                    <p>Ukurasa huu utazungumzia Taarifa kuhusu kanda zetu..</p>
                    @endif
                </div>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="icon-box">
                <i class="icofont-users-alt-5"></i>
                <h3><a href="{{url('jumuiya_zetu')}}">Jumuiya zetu</a></h3>
                    @if($jumuiya_zetu->isNotEmpty())
                        @foreach ($jumuiya_zetu as $jumuiya)
                        <p>{{$jumuiya->jina_la_jumuiya}}</p>
                        @endforeach
                    @else
                    <p>Ukurasa huu utatoa muhtasari wa Taarifa kuhusu jumuiya zetu..</p>
                    @endif
                </div>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="icon-box">
                <i class="icofont-attachment"></i>
                <h3><a href="{{url('matangazo_yetu')}}">Matangazo</a></h3>
                @if($matangazo->isNotEmpty())
                    @foreach ($matangazo as $tangazo)
                    <p> <img src="{{asset('images/new.gif')}}">{{$tangazo->kichwa}}</p>
                    @endforeach
                @else
                    <p>Ukurasa wa matangazo mbalimbali ya kanisa, maelezo mafupi kuhusu matangazo..</p>
                @endif
                </div>
            </div>
            </div>

        </div>
    </section>


    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container">

            <div class="section-title" data-aos="fade-up">
                <h2>Historia Leo</h2>
            </div>
    
            <div class="row">

            @if($historia_leo->isNotEmpty())
                @foreach ($historia_leo as $historia)
                    <div class="col-lg-6">
                        <img src="{{url('/uploads/images/'.$historia->picha)}}" class="img-fluid" alt="">
                    </div>

                    <div class="col-lg-6 pt-4 pt-lg-0 content">
                        <h3>{{$historia->kichwa}}</h3>
                        <hr>
                        <p>
                            {{$historia->maelezo}}
                        </p>
                    </div>
                @endforeach
            @else
                <div class="col-lg-6">
                    <p>Kipengele hiki kitazungumzia historia husika ya mtakatifu kulingana na tarehe husika, Tembelea ukurasa wa historia kusoma zaidi..</p>                    
                </div>
            @endif
            
            </div>
    
        </div>
        </section><!-- End About Section -->
</main>


@endsection