@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>NYARAKA MBALIMBALI</h4>
                </div>
                <div class="card-body">
                    <ul style="list-style-type: none;">

                        <li>
                            <a href="{{url('uploads/nyaraka/kanda.xls')}}" style="text-decoration: none;"><h4><i class="fas fa-fw fa-angle-double-right"></i> &nbsp;Nyaraka ya kupakia kanda</h4></a>
                        </li>

                        <li>
                            <a href="{{url('uploads/nyaraka/jumuiya.xls')}}" style="text-decoration: none;"><h4><i class="fas fa-fw fa-angle-double-right"></i> &nbsp;Nyaraka ya kupakia jumuiya</h4></a>
                        </li>

                        <li>
                            <a href="{{url('uploads/nyaraka/familia.xls')}}" style="text-decoration: none;"><h4><i class="fas fa-fw fa-angle-double-right"></i> &nbsp;Nyaraka ya kupakia familia</h4></a>
                        </li>

                        <li>
                            <a href="{{url('uploads/nyaraka/wanafamilia.xls')}}" style="text-decoration: none;"><h4><i class="fas fa-fw fa-angle-double-right"></i> &nbsp;Nyaraka ya kupakia wanafamilia</h4></a>
                        </li>

                        <li>
                            <a href="{{url('uploads/nyaraka/majina.xls')}}" style="text-decoration: none;"><h4><i class="fas fa-fw fa-angle-double-right"></i> &nbsp;Nyaraka ya kutengeneza familia, wanafamilia (wanajumuiya)</h4></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection