@if($church_details != "")
<table style="width:100%">

    <tr class="text-center">
        <td style="font-size: 18px; font-weight:500; color: #42b3e5;">
            {{strtoupper($church_details->jimbo)}}
        </td>
    </tr>

    <tr class="text-center">
        <td style="font-size: 16px; font-weight:500; color: #42b3e5;">
            {{strtoupper($church_details->centre_name)}}
        </td>
    </tr>

    <tr>
        <td style="text-align:center;">Anwani: {{$church_details->address}} {{$church_details->region}}
            {{$church_details->country}}</td>
    </tr>
    <tr>
        <td style="text-align:center;">Simu ya mezani: {{$church_details->telephone1}} || Baruapepe:
            {{$church_details->email}}</td>
    </tr>
    <tr>
        <td style="text-align: center;color: #42b3e5;">{{strtoupper($title)}}</td>
    </tr>
</table>
@endif