<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">

@if($church_details == "")
    <title>{{ config('app.name', 'Laravel') }}</title>
@else
	<title>{{$church_details}}</title>
@endif

<link rel="icon" href="{{asset('images/icon.png')}}" type="image/png">
<meta content="" name="descriptison">
<meta content="" name="keywords">
@include('meta::manager')
<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="{{asset('/web/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('/web/icofont/icofont.min.css')}}" rel="stylesheet">
<link href="{{asset('/web/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
<link href="{{asset('/web/animate/animate.min.css')}}" rel="stylesheet">
<link href="{{asset('/web/carousel/assets/owl.carousel.min.css')}}" rel="stylesheet">
<link href="{{asset('/web/venobox/venobox.css')}}" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="{{asset('/web/css/style.css')}}" rel="stylesheet">
</head>

<body>
    <!-- ======= Header ======= -->
<header id="header">
<div class="container d-flex">

    <div class="logo mr-auto">
    <h1 class="text-light">
        <a href="{{url('/')}}"><img src="{{asset('/images/atlais.png')}}" alt="" class="img-fluid"></a>
    </div>

    <nav class="nav-menu d-none d-lg-block">
    <ul>
        <li class="{{Request::is('/') ? 'active':''}}"><a href="{{url('/')}}">Nyumbani</a></li>
        <li class="{{Request::is('kanda_zetu')?'active':''}}"><a href="{{url('kanda_zetu')}}">Kanda zetu</a></li>
        <li class="{{Request::is('jumuiya_zetu')?'active':''}}"><a href="{{url('jumuiya_zetu')}}">Jumuiya</a></li>
        <li class="{{Request::is('mashirika_ya_kitume')?'active':''}}"><a href="{{url('mashirika_ya_kitume')}}">Mashirika ya Kitume</a></li>
        <li class="{{Request::is('matangazo_yetu')?'active':''}}"><a href="{{url('matangazo_yetu')}}">Matangazo</a></li>
        <li class="{{Request::is('matukio_guest')?'active':''}}"><a href="{{url('matukio_guest')}}">Matukio</a></li>
        <li class="{{Request::is('misa')?'active':''}}"><a href="{{url('misa')}}">Misa</a></li>
        <li class="{{Request::is('historia_leo')?'active':''}}"><a href="{{url('historia_leo')}}">Historia</a></li>
        <li><a href="{{url('/login')}}">Ingia</a></li>

    </ul>
    </nav><!-- .nav-menu -->

</div>
</header>

@yield('content')

<!-- ======= Footer ======= -->
<footer id="footer">

    <div class="container">
        <div class="copyright">
            Haki zimehifadhiwa &copy; {{date('Y')}} <strong><span>Atlais</span></strong>.
        </div>
    </div>

</footer>


<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="{{asset('/web/js/jquery.min.js')}}"></script>
<script src="{{asset('/web/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('/web/js/jquery.easing.min.js')}}"></script>
<script src="{{asset('/web/js/jquery.sticky.js')}}"></script>
<script src="{{asset('/web/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('/web/js/jquery.waypoints.min.js')}}"></script>
<script src="{{asset('/web/js/counterup.min.js')}}"></script>
<script src="{{asset('/web/js/isotope.pkgd.min.js')}}"></script>
<script src="{{asset('/web/js/venobox.min.js')}}"></script>

<!-- Template Main JS File -->
<script src="{{asset('/web/js/main.js')}}"></script>

</body>
