<!DOCTYPE html>
<html>
<head>
<style>
table {
    font-family: sans-serif, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue';
    border-collapse: collapse;
    width: 100%;
    font-size:10px;
}

td, th {
    text-align: left;
    margin:1px;
    padding:1px;
}

</style>
</head>
<body>

@yield('content')

</body>
</html>