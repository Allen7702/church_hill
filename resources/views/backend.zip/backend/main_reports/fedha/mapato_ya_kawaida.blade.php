@extends('layouts.master')
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                {{-- ================== THE HEADER PART =========== --}}
                <div class="card-header">
                    <div class="row text-right">
                        <div class="col-md-12">
                            <a href="{{ URL::to('mapato_ya_kawaida_print/pdf/' . $name) }}"><button class="btn btn-info btn-sm mr-2">PDF</button></a>
                            <a href="{{ URL::to('mapato_ya_kawaida_print/excel/' . $name) }}"><button class="btn btn-info btn-sm mr-0">EXCEL</button></a>
                            
                        </div>
                    </div>
                    
                    <div class="col-md-12">
                        @include('layouts.header')    
                    </div>
                </div>
                @if($name=='sadaka_za_misa')
         
                <div class="card-body">
                    <table class="table_other table">
                       
                        <thead class="bg-light">
                            <th>Misa</th>
                            <th>Kiasi</th>
                            <th>Tarehe</th>
                        </thead>
                        <tfoot>
                            <th>Jumla</th>
                            <th colspan="3">{{number_format($sadaka_za_misa->sum('kiasi'),2)}}</th>
                        </tfoot>
                        <tbody>
                             @foreach($sadaka_za_misa as $sadaka)
                            <tr>
                                <td>{{$sadaka->misa}}</td>
                                <td>{{number_format($sadaka->kiasi,2)}}</td>
                                <td>{{\Carbon\carbon::parse($sadaka->tarehe)->format('d/m/Y')}}</td>

                            </tr>
                            
                            @endforeach
                        
                           
                        </tbody>
                       
                </table>
                </div>
                @endif

                @if($name=='sadaka_za_jumuiya')
               @php $jumla=0; @endphp
                @foreach($sadaka_za_jumuiya as $sadaka)
                @php $jumla += $sadaka->kiasi;  @endphp
                @endforeach
      
              <div class="card-body">
                  <table class="table_other table">
                        
                      <thead class="bg-light">
                          <th>Jumuiya</th>
                          <th>Kiasi</th>
                          <th>Tarehe</th>
                      </thead>
                      <tfoot>
                          <th>Jumla</th>
                          <th colspan="3">{{number_format($jumla,2)}}</th>
                      </tfoot>
                      <tbody>
                           @foreach($sadaka_za_jumuiya as $sadaka)
                          
                          <tr>
                              <td>{{$sadaka->jina_la_jumuiya}}</td>
                              <td>{{number_format($sadaka->kiasi,2)}}</td>
                              <td>{{\Carbon\carbon::parse($sadaka->tarehe)->format('d/m/Y')}}</td>
                          </tr>
                          
                          @endforeach
                      
                         
                      </tbody>
                     
              </table>
              </div>
              @endif


              @if($name=='mapato_ya_zaka')
              @php $jumla=0; @endphp
               @foreach($mapato_ya_zaka as $zaka)
               @php $jumla += $zaka->kiasi;  @endphp
               @endforeach
  
             <div class="card-body">
                 <table class="table_other table">
                       
                     <thead class="bg-light">
                         <td>S/N</td>
                         <th>Kiasi</th>
                         <th>Mwezi</th>
                     </thead>
                     <tfoot>
                         <th>Jumla</th>
                         <th colspan="3">{{number_format($jumla,2)}}</th>
                     </tfoot>
                     <tbody>
                          @php $count=1; @endphp
                          @foreach($mapato_ya_zaka as $zaka)
                           
                         <tr>
                             <td>{{$count}}</td>
                             <td>{{number_format($zaka->kiasi,2)}}</td>
                             <td>{{ date("F", mktime(0, 0, 0, $zaka->mwezi, 1)) }}</td>
                         </tr>
                         @php  $count++; @endphp
                         @endforeach
                         
                     
                        
                     </tbody>
                    
             </table>
             </div>
             @endif

             @if($name=='jumla_mapato_ya_kawaida')
             <div class="card-body">
                <table class="table_other table justify-content-center">

                    <thead class="bg-light">
                        <th colspan="2" class="text-info">A: Sadaka za misa</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <tr>
                            <th >Misa</th>
                            <th>Kiasi</th>
                            <th>Tarehe</th>
                        </tr>
                        <tfoot>
                            
                            <th>Jumla</th>
                            <th colspan="3">{{number_format($sadaka_za_misa->sum('kiasi'),2)}}</th>
                        </tfoot>
                        <tbody>
                             @foreach($sadaka_za_misa as $sadaka)
                            <tr>
                                <td>{{$sadaka->misa}}</td>
                                <td>{{number_format($sadaka->kiasi,2)}}</td>
                                <td>{{\Carbon\carbon::parse($sadaka->tarehe)->format('d/m/Y')}}</td>

                            </tr>
                            
                            @endforeach
                        
                           
                        </tbody>
                    </tbody>
                </table>
                <table class="table_other table">
                    @php $jumla_jumuiya=0; @endphp
                    @foreach($sadaka_za_jumuiya as $sadaka)
                    @php $jumla_jumuiya += $sadaka->kiasi;  @endphp
                    @endforeach
                    <thead class="bg-light">
                        <th colspan="2" class="text-info">B: Sadaka za jumuiya</th>
                        <th></th>
                    </thead>
                    <tbody>
                        <th>Jumuiya</th>
                        <th>Kiasi</th>
                        <th>Tarehe</th>
                  
                    <tfoot>
                   
                        <th>Jumla</th>
                        <th colspan="3">{{number_format($jumla_jumuiya,2)}}</th>
                    </tfoot>
                    <tbody>
                         @foreach($sadaka_za_jumuiya as $sadaka)
                        
                        <tr>
                            <td>{{$sadaka->jina_la_jumuiya}}</td>
                            <td>{{number_format($sadaka->kiasi,2)}}</td>
                            <td>{{\Carbon\carbon::parse($sadaka->tarehe)->format('d/m/Y')}}</td>
                        </tr>
                        
                        @endforeach
                    
                       
                    </tbody>
                    </tbody>
                   
            </table>

            <table class="table_other table">
                @php $jumla_zaka=0; @endphp
                @foreach($mapato_ya_zaka as $zaka)
                @php $jumla_zaka += $zaka->kiasi;  @endphp
                @endforeach
                <thead class="bg-light">
                    <th colspan="2" class="text-info">C: Mapato ya zaka</th>
                    <th></th>
                </thead>

                <tbody>
                    <td>S/N</td>
                    <th>Kiasi</th>
                    <th>Mwezi</th>
                
                <tfoot>
                  
                    <th>Jumla</th>
                    <th colspan="3">{{number_format($jumla_zaka,2)}}</th>
                </tfoot>
                <tbody>
                     @php $count=1; @endphp
                     @foreach($mapato_ya_zaka as $zaka)
                      
                    <tr>
                        <td>{{$count}}</td>
                        <td>{{number_format($zaka->kiasi,2)}}</td>
                        <td>{{ date("F", mktime(0, 0, 0, $zaka->mwezi, 1)) }}</td>
                    </tr>
                    @php  $count++; @endphp
                    @endforeach
                 
                   </tbody>
                   <tbody>
                    
                   </tbody>
                </tbody>
               
        </table>
        <table class="table">
            <thead class="bg-light">
                <th colspan="3" class="text-info">Jumla ya mapato ya kawaida (A+B+C) </th>
                <th style="font-size:20px;">{{number_format($jumla_zaka+$jumla_jumuiya+$sadaka_za_misa->sum('kiasi'),2)}}</th>
            </thead>
       
        </table>


            </div>
             @endif

            </div>
        </div>
    </div>
@endsection